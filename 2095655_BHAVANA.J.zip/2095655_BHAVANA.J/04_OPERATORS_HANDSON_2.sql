use ipm002;
CREATE TABLE STUDENT_INFO(
Reg_Number Varchar(20),
Student_Name  Varchar(30),
Branch  Varchar(20),
Contact_Number  Varchar(20),
Date_of_Birth Date,
Date_of_Joining Date,
Address Varchar(250),
Email_id Varchar(25)
);

ALTER TABLE STUDENT_INFO
MODIFY EMAIL_ID VARCHAR(25) NOT NULL;

INSERT INTO STUDENT_INFO
VALUES('MC101301','James','MCA','9714589787','1984-01-12','2010-07-08','No 10 South Block','Nivea james.mca@yahoo.com'),
('BEC111402','Manio','ECE','8912457875','1983-02-23','2011-06-25','8/12 ParkView','Sieera manioma@gmail.com'),
('BEEI101204','Mike','EI','8974567897','1983-02-10','2010-08-25','Cross villa NY','mike.james@ymail.com'),
('MB111305','Paulson','MBA',8547986123,'1984-12-13','2010-08-08','Lake view NJ','paul.son@rediffmail.com');

SELECT STUDENT_NAME FROM STUDENT_INFO
WHERE NOT (EMAIL_ID IS NULL);
SELECT * FROM STUDENT_INFO;

CREATE TABLE STUDENT_MASTER(
Subject_Code varchar(20),
Subject_Name Varchar(20),
Weightage INT
);

INSERT INTO STUDENT_MASTER(Subject_Code, Subject_Name ,Weightage)
VALUES ('EE01DCF','DCF',30),
('EC02MUP','Mprocessor',40),
('MC06DIP','DigImage Processing',30),
('MB03MAR','MarketingTechniques',20),
('EI05IP','InsumentationPrecn',40),
('CPSC02DS','DataStructures',40);


CREATE TABLE STUDENT_MARKS(
REG_NO VARCHAR(20),
SUBJECT_CODE VARCHAR(20),
SEMESTER INT,
MARKS int);

ALTER TABLE STUDENT_MARKS
ADD STUDENT_NAME VARCHAR(30),
CO 
FOREIGN KEY (STUDENT_NAME) REFERENCES STUDENT_INFO(STUDENT_NAME);

insert into student_marks(Reg_NO,Subject_Code,Semester,MARKS)
VALUES ('MS102301','EE01DCF',1,75),
('MC101301','EC02MUP',1,65),
('MC101301','MC06DIP',1,70),
('BEC111402','EE01DCF',1,55),
('BEC111402','EC02MUP',1,80),
('BEC111402','MC06DIP',1,60),
('BEEI101204','EE01DCF',1,85),
('BEEI101204','EC02MUP',1,78),
('BEEI101024','MC06DIP',1,80),
('BEEI101204','MB03MAR',2,75),
('BEEI101204','EI05IP',2,65),
('BEEI101204','CPSC02DS',2,75),
('MB111305','EE01DCF',1,65),
('MB111305','EC02MUP',1,68),
('MB111305','MC06DIP',1,63),
('MB111305','MB03MAR',2,85),
('MB111305','EI05IP',2,74);

SELECT MARKS,REG_NO
FROM STUDENT_MARKS
WHERE MARKS>50;



CREATE TABLE STUDENT_RESULT(
Reg_Number Varchar(20),
Semester INT,
GPA INT,
Is_Eligible_Scholarship char(10)
);
ALTER TABLE STUDENT_TABLE 
ADD STUDENT_NAME VARCHAR(30);
ALTER TABLE STUDENT_RESULT
ADD STUDENT_NAME VARCHAR(30);
ALTER TABLE STUDENT_RESULT
MODIFY STUDENT_NAME VARCHAR(30)
CONSTRAINT FK_STUDENT_NAME CHECK (STUDENT_NAME) REFERENCES STUDENT_INFO(STUDENT_NAME);

INSERT INTO STUDENT_RESULT(Reg_Number,Semester,GPA,Is_Eligible_Scholarship)
VALUES ('MC101301',1,7.5,'Y'),
('BEC111402',1,7.1,'Y'),
('BEEI101204',1,8.3,'Y'),
('BEEI101204',2,6.9,'N'),
('MB111305',1,6.5,'N'),
('MB111305',2,6.8,'N');

select si.Reg_number, si.Student_Name, sm.Subject_code, sm.Semester, sm.Marks, smt.Subject_Name
from student_Info AS si inner join Student_marks AS sm ON si.Reg_Number = sm.Reg_NO
inner join STUDENT_MASTER as smt on smt.subject_code = sm.Subject_Code
where sm.marks>70;

SELECT Reg_Number,GPA 
FROM STUDENT_RESULT
ORDER BY IS_ELIGIBLE_SCHOLARSHIP;

select si.reg_number,si.Student_name,sm.Subject_code,sm.Marks,smt.weightage as "Weightage_Marks = sm.marks * weightage /100"
from student_info as si
inner join student_marks as sm
on si.reg_number = sm.reg_no
inner join student_master as smt
on sm.subject_code = smt.subject_code;

select * from student_info
where student_name like 'M%';

select si.Student_Name,si.Reg_number,sm.MARKS
from student_info AS si
inner join student_marks as sm
on si.Reg_number=sm.reg_no
where si.email_id IS NOT NULL;

SELECT si.student_name,si.reg_number,sm.marks
from student_info as si
inner join student_marks as sm
on si.reg_number=sm.reg_no
where sm.marks>60 and sm.marks<100;

SELECT si.student_name,si.reg_number,sm.marks
from student_info as si
inner join student_marks as sm
on si.reg_number=sm.reg_no
where si.student_name not like('j%');

SELECT si.student_name,si.reg_number,sm.marks
from student_info as si
inner join student_marks as sm
on si.reg_number=sm.reg_no
where sm.subject_code  not like ('EE01DCF') and sm.subject_code not like('EC02MUP');

select * from student_info
where student_name like '%on%'



