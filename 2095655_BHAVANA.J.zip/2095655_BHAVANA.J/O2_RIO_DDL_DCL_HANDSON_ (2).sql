USE IPM002;

CREATE TABLE STUDENT_INFO(
Reg_Number Varchar(20),
Student_Name  Varchar(30),
Branch  Varchar(20),
Contact_Number  Varchar(20),
Date_of_Birth Date,
Date_of_Joining Date,
Address Varchar(250),
Email_id Varchar(25)
);

INSERT INTO STUDENT_INFO
VALUES('MC101301','James','MCA','9714589787','1984-01-12','2010-07-08','No 10 South Block','Nivea james.mca@yahoo.com'),
('BEC111402','Manio','ECE','8912457875','1983-02-23','2011-06-25','8/12 ParkView','Sieera manioma@gmail.com'),
('BEEI101204','Mike','EI','8974567897','1983-02-10','2010-08-25','Cross villa NY','mike.james@ymail.com'),
('MB111305','Paulson','MBA',8547986123,'1984-12-13','2010-08-08','Lake view NJ','paul.son@rediffmail.com');

CREATE TABLE STUDENT_MASTER(
Subject_Code varchar(20),
Subject_Name Varchar(20),
Weightage INT
);

INSERT INTO STUDENT_MASTER(Subject_Code, Subject_Name ,Weightage)
VALUES ('EE01DCF','DCF',30),
('EC02MUP','Mprocessor',40),
('MC06DIP','DigImage Processing',30),
('MB03MAR','MarketingTechniques',20),
('EI05IP','InsumentationPrecn',40),
('CPSC02DS','DataStructures',40);

CREATE TABLE STUDENT_MARKS(
REG_NO VARCHAR(20),
SUBJECT_CODE VARCHAR(20),
SEMESTER INT,
MARKS int);



insert into student_marks(Reg_NO,Subject_Code,Semester,MARKS)
VALUES ('MS102301','EE01DCF',1,75),
('MC101301','EC02MUP',1,65),
('MC101301','MC06DIP',1,70),
('BEC111402','EE01DCF',1,55),
('BEC111402','EC02MUP',1,80),
('BEC111402','MC06DIP',1,60),
('BEEI101204','EE01DCF',1,85),
('BEEI101204','EC02MUP',1,78),
('BEEI101024','MC06DIP',1,80),
('BEEI101204','MB03MAR',2,75),
('BEEI101204','EI05IP',2,65),
('BEEI101204','CPSC02DS',2,75),
('MB111305','EE01DCF',1,65),
('MB111305','EC02MUP',1,68),
('MB111305','MC06DIP',1,63),
('MB111305','MB03MAR',2,85),
('MB111305','EI05IP',2,74);

CREATE TABLE STUDENT_RESULT(
Reg_Number Varchar(20),
Semester INT,
GPA INT,
Is_Eligible_Scholarship char(10)
);

INSERT INTO STUDENT_RESULT(Reg_Number,Semester,GPA,Is_Eligible_Scholarship)
VALUES ('MC101301',1,7.5,'Y'),
('BEC111402',1,7.1,'Y'),
('BEEI101204',1,8.3,'Y'),
('BEEI101204',2,6.9,'N'),
('MB111305',1,6.5,'N'),
('MB111305',2,6.8,'N');


