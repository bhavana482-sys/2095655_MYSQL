package com.bhavana.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.bhavana.Model.StaffRegister;
import com.bhavana.service.Staffdao;
@org.springframework.stereotype.Controller
public class Controller {
	
	
	@Autowired
	StaffRegister staffReg;
	
	
	@Autowired
	Staffdao staffDao;
	
	String msg;
	
	@RequestMapping("/")
	public String first() 
	{
		return "index";

	}
	
	@RequestMapping("validate")
	public String validateStaff(@ModelAttribute("staffReg") StaffRegister staffReg, Model mv , HttpSession session ) 
	{
		StaffRegister staffReg1 = staffDao.validateStaff(staffReg);
		if(staffReg1!=null) 	
		{
			msg = "Login Successful";
			session.setAttribute("staffReg", staffReg1.getUserName());
			System.out.println("Login Successful");
			return "redirect:/getall";
		}
		else 
		{
			System.out.println("Login Failed");
			msg = "Login Failed";
			return "redirect:/loginstaff";
		}
	}
	
	 @RequestMapping("staff")
	 public String second() 
	 {
		 return "staff";
	 }
	 
	 @RequestMapping("loginstaff")
	 public String stafflogin() {
		 
		 return "staffLogin";
	 }
	 
	 @RequestMapping("registerstaff")
	 public ModelAndView staffregister(ModelAndView model) {
		 model.addObject("staffReg",staffReg);
		 model.setViewName("staffRegister");
		 return model;
	 }
	 
	 
		 
	  @RequestMapping("submitform")
	 public ModelAndView saveStudent(@ModelAttribute("staffReg") StaffRegister staffReg, ModelAndView mv, @RequestParam("pic") MultipartFile file) throws IOException {



	 System.out.println("In Save Student");
	 byte[] stuPic = file.getBytes();
	 staffReg.setStaffPic(stuPic);
	 staffDao.addStaff(staffReg);
	 mv.addObject("msg", "Staff Added Successfully");
	 mv.setViewName("showdetails");
	 return mv;
	 }
	 
	 @RequestMapping("getall")
	 public ModelAndView getAllStudents(ModelAndView mv) {
	 List<StaffRegister> staffRegList = staffDao.getAllStaffRegister();
	 System.out.println(staffRegList);
	 mv.addObject("staffReg",staffRegList);
	 mv.addObject("msg", msg);
	 mv.setViewName("Viewall");
	 return mv;
	 }
	 
	 @RequestMapping("Edit/{id}")
	 public ModelAndView getUpdateStaff(@PathVariable int id, ModelAndView mv) {

	 StaffRegister staffReg = staffDao.getStaffRegisterById(id);
	 System.out.println("In Controller : "+staffReg);
	 //m.addAttribute("staffReg", staffReg);
	 mv.addObject("staffReg", staffReg);
	 mv.setViewName("/updateform");
     return mv;
	 }
	 
	 @RequestMapping("/saveUpdate")
	 public String saveUpdate(@ModelAttribute("staffReg") StaffRegister staffReg) {
	 System.out.println("in edit");
	 staffDao.updateStaff(staffReg);
	 return "redirect:/getall";
	 }
	 
	 @RequestMapping("Delete/{id}")
	 public String deleteStaffRegister(@PathVariable int id) {
	 System.out.println("in delete student");
	 staffDao.deleteStaff(id);
	 return "redirect:/getall";
	 }
	
}