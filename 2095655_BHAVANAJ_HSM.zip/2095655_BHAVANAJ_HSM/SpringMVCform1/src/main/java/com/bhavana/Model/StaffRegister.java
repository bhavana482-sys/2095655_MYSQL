package com.bhavana.Model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;


@Entity
@Component
public class StaffRegister {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer staffid;
	private String staffName;
	private int staffAge;
	private String staffGender;
	private String department;
	private String workknown;
	private String userName;
	private String password;
	//@DateTimeFormat(pattern="mm-dd-YYYY")
	private Date staffJoindate;
	@Lob
	private byte[] staffPic;
	public StaffRegister() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StaffRegister(Integer staffid, String staffName, int staffAge, String staffGender, String department,
			String workknown, String userName, String password, Date staffJoindate) {
		super();
		this.staffid = staffid;
		this.staffName = staffName;
		this.staffAge = staffAge;
		this.staffGender = staffGender;
		this.department = department;
		this.workknown = workknown;
		this.userName = userName;
		this.password = password;
		this.staffJoindate = staffJoindate;
	}
	
	
	public StaffRegister(Integer staffid, String staffName, int staffAge, String staffGender, String department,
			String workknown, String userName, String password, Date staffJoindate, byte[] staffPic) {
		super();
		this.staffid = staffid;
		this.staffName = staffName;
		this.staffAge = staffAge;
		this.staffGender = staffGender;
		this.department = department;
		this.workknown = workknown;
		this.userName = userName;
		this.password = password;
		this.staffJoindate = staffJoindate;
		this.staffPic = staffPic;
	}
	public Integer getStaffid() {
		return staffid;
	}
	public void setStaffid(Integer staffid) {
		this.staffid = staffid;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public int getStaffAge() {
		return staffAge;
	}
	public void setStaffAge(int staffAge) {
		this.staffAge = staffAge;
	}
	public String getStaffGender() {
		return staffGender;
	}
	public void setStaffGender(String staffGender) {
		this.staffGender = staffGender;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getWorkknown() {
		return workknown;
	}
	public void setWorkknown(String workknown) {
		this.workknown = workknown;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getStaffJoindate() {
		return staffJoindate;
	}
	public void setStaffJoindate(Date staffJoindate) {
		this.staffJoindate = staffJoindate;
	}
	
	public byte[] getStaffPic() {
		return staffPic;
	}
	public void setStaffPic(byte[] staffPic) {
		this.staffPic = staffPic;
	}
	
	public String getUserPicture() {
		return Base64.encodeBase64String(staffPic);
		}
	@Override
	public String toString() {
		return "StaffRegister [staffid=" + staffid + ", staffName=" + staffName + ", staffAge=" + staffAge
				+ ", staffGender=" + staffGender + ", department=" + department + ", workknown=" + workknown
				+ ", userName=" + userName + ", password=" + password + ", staffJoindate=" + staffJoindate + "]";
	}


}



