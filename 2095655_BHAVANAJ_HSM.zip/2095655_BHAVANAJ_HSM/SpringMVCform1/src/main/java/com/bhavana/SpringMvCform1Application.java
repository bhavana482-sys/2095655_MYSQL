package com.bhavana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvCform1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvCform1Application.class, args);
	}

}
