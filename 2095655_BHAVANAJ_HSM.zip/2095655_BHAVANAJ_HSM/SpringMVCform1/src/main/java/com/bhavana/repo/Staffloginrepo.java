package com.bhavana.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bhavana.Model.StaffRegister;

@Repository
public interface Staffloginrepo extends JpaRepository<StaffRegister, Integer> {
	@Query("select s from StaffRegister s where s.userName=(:userName) and s.password=(:password)")
	StaffRegister findByLoginData(String userName, String password);
}
