package com.bhavana.service;

import org.springframework.stereotype.Service;


import com.bhavana.Model.StaffRegister;
import java.util.List;

@Service
public interface Staffdao 
{
	public void regstaff(StaffRegister staffReg);
	public void addStaff(StaffRegister staffReg);
	public List<StaffRegister> getAllStaffRegister();
	public StaffRegister getStaffRegisterById(int id);
	public void updateStaff(StaffRegister staffReg);
	public void deleteStaff(int staffid);
	public StaffRegister validateStaff(StaffRegister staffReg);
	
	

}
