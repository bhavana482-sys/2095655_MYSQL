package com.bhavana.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bhavana.Model.StaffRegister;
import com.bhavana.repo.Staffloginrepo;

@Service
public class Staffservice implements Staffdao {

	 @Autowired
	 Staffloginrepo staffRep;
	
	@Override
	public void regstaff(StaffRegister staffReg) {
		staffRep.save(staffReg);
	}

	@Override
	public StaffRegister validateStaff(StaffRegister staffReg) {
		StaffRegister staffReg1 = staffRep.findByLoginData(staffReg.getUserName(), staffReg.getPassword());
		return staffReg1;
	}

	@Override
	public void addStaff(StaffRegister staffReg) {
		staffRep.save(staffReg);
		
	}

	@Override
	public List<StaffRegister> getAllStaffRegister() {
		List<StaffRegister> staffRegList = staffRep.findAll();
		return staffRegList;
	}

	@Override
	public StaffRegister getStaffRegisterById(int id) {
		StaffRegister staffReg=staffRep.getById(id);
		return staffReg;
	}

	@Override
	public void updateStaff(StaffRegister staffReg) {
		staffRep.save(staffReg);
		
	}

	@Override
	public void deleteStaff(int staffid) {
		// TODO Auto-generated method stub
		staffRep.deleteById(staffid);
	}

	

}