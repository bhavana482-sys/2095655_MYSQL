import java.util.*;
public interface CustomerOperation 
{
	public int addCustomerDetails(CustomerDetails customer);
	public List<CustomerDetails> getAllCustomerDetails();
	public List<CustomerDetails> getCustomerDetailsByDate();
	public int updateCustomerDetails(CustomerDetails customer);
	public int bookCustomerRoom();
}
