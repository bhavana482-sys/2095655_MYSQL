import java.util.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.util.Pair;
import java.util.*;
public class RandomClass 
{
	         //Scanner sc = new Scanner(System.in);
		static List<String>companyName = new ArrayList<String>();
		static List<String>employeeName = new ArrayList<String>();
		static List<Integer>employeeID = new ArrayList<Integer>();
		static List<Long>phoneNumber = new ArrayList<Long>();
		static List<String>email_ID = new ArrayList<String>();
		
		static int n;
		static int set=1;
		static int maxroomAC = 50;
		static int maxroomNonAC = 50;
		static int regcount = 0;
		static int roomcountAC = 0;
		static int roomcountNonAC = 0;
		static long timeDiff;
		
		static void menu()
		{
		      System.out.println(" Welcome");
		      System.out.println("1. Registeration Process - To make a new registration");
		      System.out.println("2. Room Details - Book a room, check room status and availabilities");
		      System.out.println("3. All booking details of the rooms in the hotel");
		      System.out.println("4. Email change or updation");
		      System.out.println("5. All Customers");
		      System.out.println("6. Quit");
		      System.out.println("Select an option");
		}
		
		static void register()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter your Company name : ");
			companyName.add(sc.nextLine());
			System.out.println("Please enter your name : ");
			employeeName.add(sc.nextLine());
			System.out.println("Please enter your Employee ID : ");
			employeeID.add(sc.nextInt());
			System.out.println("Please enter your Phone number : ");
			phoneNumber.add(sc.nextLong());
			System.out.println("Please enter your email ID : ");
			email_ID.add(sc.next());
			sc.nextLine();
			System.out.println("Please enter the date : ");
			LocalDate l_date = LocalDate.now();        
		    System.out.println("Date : " + l_date);
			System.out.println(companyName.toString());
			System.out.println(employeeName.toString());
			System.out.println(employeeID.toString());
			System.out.println(phoneNumber.toString());
			System.out.println(email_ID.toString());
			//System.out.println("Current date: " + l_date);
			regcount++; //regcount = regcount+1
			
			sc.nextLine();
			System.out.println("Please select an option");
			System.out.println("0. I want to register a new person");
			System.out.println("1. Quit");
			int reg = sc.nextInt();
			if(reg == 0)
			{
				register();
			}
			else 
			{
				System.out.println("Thankyou");
			}
			sc.nextLine();
			System.out.println("Please select an option");
			System.out.println("0. I would like to book a room");
			System.out.println("1. I would like to open menu");
			System.out.println("2. Quit");
			int check = sc.nextInt();
			if(check == 0)
			{
				roomBooking();
			}
			else if(check == 1)
			{
				MenuList.main(null);
			}
			else
			{
				System.out.println("Thankyou");
			}
		}
		
		static Pair <Integer,Integer> roomBooking()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Please select an option");
			System.out.println("0. Registration");
			System.out.println("1. Continue Booking");
			System.out.println("2. Menu");
			int x = sc.nextInt();
			if(x == 0)
			{
				register();
				roomBooking();
				MenuList.main(null);
			}
			else if(x == 1)
			{   
				System.out.println("Please enter registered email_ID");
				String emailID = sc.next();
				boolean ans = email_ID.contains(emailID);
				if(ans == true)
				{
					System.out.println("Please select the tgype of room \n 1. AC Rooms \n 2. Non AC Rooms");
					System.out.println("Note - Each room can be occupied with 2 people only");
					int option = sc.nextInt();
					if(option==1)
					{
						int n;
						System.out.println("Please enter the number of rooms");
						n = sc.nextInt();
						for(int i=1;i<=n;i++)
						{
							System.out.println("You are allocated with the room number : "+ set);
							roomcountAC++;
							set++;
						}
						
						date();
						System.out.println("Cost per dayis Rs 500/-");
						System.out.println("The total price for the room is " + n*500*timeDiff);
						System.out.println("Thankyou, your booking is been confirmed");
						System.out.println("Vacant rooms count : " + (maxroomAC-roomcountAC));
					 //quit();
					
					}
					else if(option==2)
					{
						int i;
						System.out.println("Please enter the number of rooms");
						n = sc.nextInt();
						for(i=1;i<=n;i++)
						{
							System.out.println("You are allocated with the room number : "+ set);
							roomcountNonAC++;
							set++;
						}
						date();
						System.out.println("Cost per dayis Rs 250/-");
						System.out.println("The total price for the room is " + n*250*timeDiff);
						System.out.println("Thankyou, your booking is been confirmed");
						System.out.println("Vacant rooms count : " + (maxroomNonAC-roomcountNonAC));
					//quit();
					}
					else
					{
						System.out.println("Sorry Please Select either option 1 or option 2");
					}
				}
				else
				{
					System.out.println("Unregistered mail ID");
					System.out.println("Please register");
					register();
					MenuList.main(null);
				}
			}
			else 	
			{
				MenuList.main(null);
			}
			return new Pair <Integer, Integer> (maxroomAC,maxroomNonAC);
		}
		static void roomDetails()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Please select an option");
			System.out.println("0. Continue checking the room details");
			System.out.println("1. Menu");
			int y = sc.nextInt();
			if(y == 0)
			{
				System.out.println("Please enter registered email_ID");
				String emailID = sc.next();
				boolean ans = email_ID.contains(emailID);
				if(ans == true)
				{
					for(int i=1;i<=roomcountAC;i++)
					{
						System.out.println("Room number " + i + " in AC type is been Occupied");
					}
					for(int i=1;i<=roomcountNonAC;i++)
					{
						System.out.println("Room number " + i + " in non AC type Occupied");
					}
					System.out.println("Vacant rooms count of non AC type : " + (maxroomAC-roomcountNonAC));
					System.out.println("Vacant rooms count of AC type : " + (maxroomAC-roomcountAC));
					quit();
				}
				else
				{
					System.out.println("Unregistered mail ID");
					System.out.println("Please register");
					register();
					MenuList.main(null);
				}
				
			}
			else
			{
				MenuList.main(null);
			}
		}	
		static void emailUpdation()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Please select an option");
			System.out.println("0. Continue with email updation");
			System.out.println("1. Menu");
			int z = sc.nextInt();
			if(z == 0)
			{   
				System.out.println("Please enter registered email_ID");
				String emailID = sc.next();
				boolean ans = email_ID.contains(emailID);
				if(ans == true)
				{
					System.out.println("Please enter your new email : ");
					int index = email_ID.indexOf(email_ID.set(0,sc.next()));
					System.out.println("Your company name : " + companyName.toString());
					System.out.println("Your name : " + employeeName.toString());
					System.out.println("Your Employee ID : " + employeeID.toString());
					System.out.println("Your mobile number : " + phoneNumber.toString());
					System.out.println("Your updated email_ID : " + email_ID.toString());
					quit();
				}
				else
				{
					System.out.println("Unregistered mail ID");
					System.out.println("Please register");
					register();
					MenuList.main(null);
				}
			}
			else
			{
				MenuList.main(null);
			}
		}
		static void allCustomers()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Please select an option");
			System.out.println("0. Continue to fetch the details of all customers");
			System.out.println("1. Menu");
			int a = sc.nextInt();
			if(a == 0)
			{
				System.out.println("Please enter registered email_ID");
				String emailID = sc.next();
				boolean ans = email_ID.contains(emailID);
				if(ans == true)
				{
					System.out.println("Your company name : " + companyName.toString());
					System.out.println("Your name : " + employeeName.toString());
					System.out.println("Your Employee ID : " + employeeID.toString());
					System.out.println("Your mobile number : " + phoneNumber.toString());
					quit();
				}
				else
				{
					System.out.println("Sorry, access denayed ");
					MenuList.main(null);
				}
			}	
			else
			{
				MenuList.main(null);
			}
		}
		static void quit()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Please select an option");
			System.out.println("0. Continue with Quitting Process");
			System.out.println("1. Menu");
			int b = sc.nextInt();
			if(b == 0)
			{
				System.out.println(" Thankyou for using our application");
		    	System.out.println(" HAVE A GOOD DAY ! ");
			}
			else
			{
				MenuList.main(null);
			}
		}
		static long date()
		{
		     System.out.println("enter check out date");
		     Scanner sc=new Scanner(System.in);
		     String s1=sc.next();
		     LocalDate todaysDate = LocalDate.now();
		     System.out.println("checkin date "+todaysDate);
		     LocalDate entered_date = LocalDate.parse(s1);
		     System.out.println("check out date "+entered_date);
		     LocalDate l_date = LocalDate.now();
		     System.out.println("Checking for room availability.....");
		     if(todaysDate.compareTo(entered_date)>0)
		     {
		         System.out.println("Rooms not available");
		     }
		     if(todaysDate.compareTo(entered_date)<0)
		     {
		         System.out.println("Rooms available");
		         timeDiff = entered_date.getDayOfMonth()-todaysDate.getDayOfMonth() ;
		     }
		     return timeDiff;
		}
		static void roomDetailsDate()
		{
			 System.out.println("Please enter the date to check the availability : ");
		     Scanner sc=new Scanner(System.in);
		     String s1=sc.next();
		     LocalDate todaysDate = LocalDate.now();
		     System.out.println("current date is "+todaysDate);
		     LocalDate entered_date = LocalDate.parse(s1);
		     System.out.println("entered date is "+entered_date);
		     LocalDate l_date = LocalDate.now();
		     if(todaysDate.compareTo(entered_date)>0)
		     {
		         System.out.println("Rooms");
		     }
		     if(todaysDate.compareTo(entered_date)<0)
		     {
		         System.out.println("Rooms available");
		     }
		}
}
